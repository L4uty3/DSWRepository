
package domain;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Ventana extends JFrame {
    public void miVentana() {
        setTitle("añadir animal");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(rootPane);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
    }

}
