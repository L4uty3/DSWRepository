# dsw2025ej1
Desarrollo de Software 2025 - Ejercicio N° 1 - El Zoológico
Se trata de un zoológico que solo cuenta con una clase de animales, 
los mamíferos. Cuando un nuevo animal llega al zoológico, se completa 
una ficha con sus datos (nombre, especie, edad, peso) y el sector donde 
será alojado. 
Para organizar mejor la población, se divide a los mamíferos en dos 
tipos según su alimentación, carnívoros y herbívoros, porque son los 
únicos pobladores del zoológico. Esto, además, ayuda a la administración 
a determinar los kilos de alimentos que se deben comprar.
Los sectores del zoológico están identificados con un número, sus 
coordenadas (latitud y longitud) y el empleado encargado.
Para tener un estimado de los kilos de alimentos a comprar, se sabe 
que los carnívoros comen a diario un determinado porcentaje de su peso 
en carne, dependiendo de la especie. Y si el carnívoro pesa más de 200kgs., 
debe sumarse un 10% más. En cambio los herbívoros comen, por día, 
2 veces su peso en hierbas, más un valor fijo (en kilos) que depende de 
cada animal y se determina al cargar su ficha.
De los empleados se conoce su nombre, número de documento y domicilio.
Reglas de implementación:
Los datos se deben almacenar en memoria.
